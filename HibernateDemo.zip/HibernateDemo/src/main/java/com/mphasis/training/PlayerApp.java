package com.mphasis.training;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.mphasis.training.bo.PlayerBOImplmentation;
import com.mphasis.training.entities.Player;
import com.mphasis.training.exception.PlayerException;



/**
 * Hello world!
 *
 */
public class PlayerApp 
{
	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		PlayerBOImplmentation playerBO=new PlayerBOImplmentation();
		System.out.println("WELOCME TO PLAYER APP");
		
		do {
			System.out.println("1.Get Player By Id\n2.Get Player By Name\n3.Get Player By Gender\n4.Get Player By Contact\n5.Get Player By Email"
					+ "\n6.Get Player By Team Name\n7.Get Player By Age\n8.Get Player By DOB\n9.Get Player By Score\n10.Get All\n11.Log out");
			switch(sc.nextInt()) {
			case 1:System.out.println("Enter Player ID");
				
				try {
					Player player = playerBO.getPlayerById(sc.nextInt());
					
					System.out.println(player);
					
				} catch (PlayerException e) {
					
					System.out.println(e.getMessage());
				}
			
			break;
			
			case 2: System.out.println("Enter Player Name");
				try {
				
					playerBO.getPlayerByName(sc.next()).forEach(System.out::println);
					
					} catch (PlayerException e) {
					
					System.out.println(e.getMessage());
				}
				break;
			case 3: System.out.println("Enter Player Gender");
			try {
				playerBO.getPlayerByGender(sc.next()).forEach(System.out::println);
					
		
			} catch (PlayerException e) {
				System.out.println(e.getMessage());
			}
			break;
			case 4: System.out.println("Enter Player Contact Number");
			try {
				System.out.println(playerBO.getPlayerByContact(sc.next()));
			
		
			} catch (PlayerException e) {
				System.out.println(e.getMessage());
			}
			break;
			case 5: System.out.println("Enter Player Email");
			try {
				
				System.out.println(playerBO.getPlayerByEmail(sc.next()));
				
					
				
			} catch (PlayerException e) {
				System.out.println(e.getMessage());
			}
			break;
			case 6: System.out.println("Enter Player Team Name");
			try {
				playerBO.getPlayerByTeamName(sc.next()).forEach(System.out::println);
			
					
				
			} catch (PlayerException e) {
				System.out.println(e.getMessage());
			}
			break;
			case 7: System.out.println("Enter Player Age");
			try {
				playerBO.getPlayerByAge(sc.nextInt()).forEach(System.out::println);
			
						
					
			} catch (PlayerException e) {
				System.out.println(e.getMessage());
			}
			break;
			case 8: System.out.println("Enter Player DOB (date/month/year)");
			try {
				//LocalDate date=LocalDate.of(sc.nextInt(), sc.nextInt(), sc.nextInt());
				
				String sDate=sc.next();
				//Date date=new SimpleDateFormat("dd-MMM-yyyy").parse(sDate);
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				Date date = df.parse(sDate);
				//System.out.println(fromDate);
			    playerBO.getPlayerByDOB(date).forEach(System.out::println);
				
					
				
			} catch (PlayerException e) {
				System.out.println(e.getMessage());
			} 
			break;
			case 9: System.out.println("Enter Player Score");
			try {
				playerBO.getPlayerByScore(sc.nextInt()).forEach(System.out::println);
				
					
				
			} catch (PlayerException e) {
				System.out.println(e.getMessage());
			}
			break;
			case 10:System.out.println("Getting all records");
				try {
					playerBO.getAllPlayers().forEach(System.out::println);
				} catch (PlayerException e) {
					
					System.out.println(e.getMessage());
				}
				break;
			
			case 11:System.out.println("Logged out");
			sc.close();
			default:
				break;
			
			}
		}while(true);
		

	}

}
