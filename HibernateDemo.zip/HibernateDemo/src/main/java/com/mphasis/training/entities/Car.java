package com.mphasis.training.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Car {

	@Id
	private long carNumber;
	@Column(length = 20)
	private String carBrand;
	
	
	
	@ManyToMany(mappedBy="cars")
	private List<Customer> customers=new ArrayList<>();
	
	
	
//	@ManyToOne
//	private Customer customer;
//	
//	
//
//	public Customer getCustomer() {
//		return customer;
//	}
//
//	public void setCustomer(Customer customer) {
//		this.customer = customer;
//	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

	public long getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(long carNumber) {
		this.carNumber = carNumber;
	}

	public String getCarBrand() {
		return carBrand;
	}

	public void setCarBrand(String carBrand) {
		this.carBrand = carBrand;
	}
	
	
	
	
}
