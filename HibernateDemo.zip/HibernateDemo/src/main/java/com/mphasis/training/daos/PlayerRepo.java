package com.mphasis.training.daos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.mphasis.training.entities.Player;


public class PlayerRepo {
	SessionFactory sessionFactory=null;
	public PlayerRepo()
	{
		Configuration con=new Configuration().configure().addAnnotatedClass(Player.class);
		StandardServiceRegistryBuilder service=new StandardServiceRegistryBuilder().applySettings(con.getProperties());
		sessionFactory=con.buildSessionFactory(service.build());
		
	}
	
	
public Player retrievePlayerById(int id)
{
	Session session=sessionFactory.openSession();
	Player player=(Player) session.get(Player.class, id);
	session.close();
	return player;
	
	
}
public List<Player> retrievePlayerByName(String name)
{
	List<Player> players=new ArrayList<Player>(); 
	Session session=sessionFactory.openSession();
	players=session.createCriteria(Player.class).add(Restrictions.eq("name", name)).list();
	session.close();
	return players;
	
}
public List<Player> retrievePlayerByGender(String gender)
{
	List<Player> players=new ArrayList<Player>(); 
	Session session=sessionFactory.openSession();
	players=session.createCriteria(Player.class).add(Restrictions.eq("gender", gender)).list();
	session.close();
	return players;
	
}
public List<Player> retrievePlayerByTeamName(String teamName)
{
	List<Player> players=new ArrayList<Player>(); 
	Session session=sessionFactory.openSession();
	players=session.createCriteria(Player.class).add(Restrictions.eq("teamName", teamName)).list();
	session.close();
	return players;
	
}
public List<Player> retrievePlayerByAge(int age)
{
	List<Player> players=new ArrayList<Player>(); 
	Session session=sessionFactory.openSession();
	players=session.createCriteria(Player.class).add(Restrictions.eq("age", age)).list();
	session.close();
	return players;
	
}
public List<Player> retrievePlayerByDOB(Date date)
{
	List<Player> players=new ArrayList<Player>(); 
	try {
	
	Session session=sessionFactory.openSession();
	java.sql.Date dates=new java.sql.Date(date.getTime());
	//System.out.println(dates);
	System.out.println(date);
	players=session.createCriteria(Player.class).add(Restrictions.eq("date", dates)).list();

	session.close();
	
	}catch(Exception e) {
		e.printStackTrace();
	}
	return players;
	
}
public List<Player> retrievePlayerByScore(long score)
{
	List<Player> players=new ArrayList<Player>(); 
	Session session=sessionFactory.openSession();
	players=session.createCriteria(Player.class).add(Restrictions.eq("score", score)).list();
	session.close();
	return players;
	
}

public Player retrievePlayerByPhoneNumber(String PhoneNumber)
{
	Session session=sessionFactory.openSession();
	Player player=(Player) session.createCriteria(Player.class).add(Restrictions.eq("contact", PhoneNumber));
	session.close();
	return player;
	
	
}
public Player retrievePlayerByEmail(String Email)
{
	Session session=sessionFactory.openSession();
	Player player=(Player) session.createCriteria(Player.class).add(Restrictions.eq("email", Email));
	session.close();
	return player;
	
	
}

public List<Player> retrieveAllPlayers()
{
	List<Player> players=new ArrayList<Player>();
	Session session=sessionFactory.openSession();
	players=session.createCriteria(Player.class).list();
	return players;
}





	

}
