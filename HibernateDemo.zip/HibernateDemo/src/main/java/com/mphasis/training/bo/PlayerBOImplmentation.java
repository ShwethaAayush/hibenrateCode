package com.mphasis.training.bo;
import java.util.Date;
import java.util.List;

import com.mphasis.training.daos.PlayerRepo;
import com.mphasis.training.entities.Player;
import com.mphasis.training.exception.PlayerException;



public class PlayerBOImplmentation  {

PlayerRepo playerRepo=null;
	public PlayerBOImplmentation() {
	playerRepo=new PlayerRepo();
}

	public Player getPlayerById(int id) throws PlayerException {
		
		if(id>=1 && id<=16)
		{
			Player player=playerRepo.retrievePlayerById(id);
			if(player==null)
			{
				throw new PlayerException("no matching data found");
			}
			return player;
		}
		else
		{
			throw new PlayerException("id should be between 1 to 16");
		}
		
		
	}


	public List<Player> getPlayerByName(String name) throws PlayerException {
	
		if(name.matches("[A-Z]{1}[a-z]{4,14}"))
		{
			List<Player> players=playerRepo.retrievePlayerByName(name);
			if(players.isEmpty())
			{
				throw new PlayerException("no matching data found");
			}
			return players;
		}
		else
		{
			throw new PlayerException("Name should have 1st letter upper case and other letters lower case.\n"
					+ "Length of the name should be between 5 to 15 letters");
		
		}
		
	}


	public List<Player> getPlayerByGender(String gender) throws PlayerException {
		if(gender.matches("[M|F|m|f]"))
		{
			List<Player> players=playerRepo.retrievePlayerByGender(gender.toUpperCase());
			if(players.isEmpty())
			{
				throw new PlayerException("no matching data found");
			}
			return players;
		}
		else
		{
			throw new PlayerException("Gender should be either M/F/m/f");
		}
		
	}

	
	public Player getPlayerByContact(String contact) throws PlayerException {
		
		if(contact.matches("^((\\+){1}91(\\-){1}){1}[6-9]{1}[0-9]{9}$"))
		{
			Player player=playerRepo.retrievePlayerByPhoneNumber(contact);
			if(player == null)
			{
				throw new PlayerException("no matching data found");
			}
			return player;
		}
		else
		{
			throw new PlayerException("Contact number should be in the format +91- then followed by 10 digits");
		}
		
	}

	public Player getPlayerByEmail(String email) throws PlayerException {
		
		if(email.matches("^(?=.*[0-9]+.*)(?=.*[a-z]+.*)(?=.*[A-Z]+.*)[0-9a-zA-Z]{5,}(@gmail.com)$"))
		
		{
			Player player=playerRepo.retrievePlayerByEmail(email);
			if(player==null)
			{
				throw new PlayerException("no matching data found");
			}
			return player;
		}
		else
		{
			throw new PlayerException("manadatory one lowercase, one uppercase, one number and @gmail.com");
		}
		
	}

	
	public List<Player> getPlayerByTeamName(String teamName) throws PlayerException {
		
		if(teamName.matches("[a-z]{5,10}"))
		{
			List<Player>  players=playerRepo.retrievePlayerByTeamName(teamName);
			if(players.isEmpty())
			{
				throw new PlayerException("no matching data found");
			}
		    return players;
		}
		else
		{
			throw new PlayerException("only lower case letters with 5 to 10 length"); 
		}
		
	}

	
	public List<Player> getPlayerByAge(int age) throws PlayerException {
		
		if(age>=18 && age<=20)
		{
			List<Player> players=playerRepo.retrievePlayerByAge(age);
			if(players.isEmpty())
			{
				throw new PlayerException("no matching data found");
			}
			return players;
		}
		else
		{
			throw new PlayerException(" Age should be between 18 to 20"); 
		}
		
	}


	public List<Player> getPlayerByDOB(Date date) throws PlayerException {
		
		if(date.before(new Date()))
				                            //date.isBefore(LocalDate.now()))
		{
			List<Player> players=playerRepo.retrievePlayerByDOB(date);
			if(players.isEmpty())
			{
				throw new PlayerException("no matching data found");
			}
			return players;
		}
		else
		{
			throw new PlayerException(" No future dates allowed"); 
		}
		
	}

	
	public List<Player> getPlayerByScore(int score) throws PlayerException {
	
		if(score>=80)
		{
			List<Player>  players=playerRepo.retrievePlayerByScore(score);
			if(players.isEmpty())
			{
				throw new PlayerException("no matching data found");
			}
			return players;
		}
		else
		{
			throw new PlayerException(" Score should be above 80"); 
		}
		
	}
	
	public List<Player> getAllPlayers() throws PlayerException {
		List<Player> players=playerRepo.retrieveAllPlayers();
		if(players.isEmpty())
		{
			throw new PlayerException("No Data FOund");
		}
		return players;
	}
	

}
