package com.mphasis.training;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.mphasis.training.entities.Car;
import com.mphasis.training.entities.Customer;


public class DemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration con=new Configuration().configure().addAnnotatedClass(Customer.class).addAnnotatedClass(Car.class);
		StandardServiceRegistryBuilder builder=
				new StandardServiceRegistryBuilder().applySettings(con.getProperties());
		SessionFactory sessionFactory = con.buildSessionFactory(builder.build());
		
//		Session s=sessionFactory.openSession();
//		
//		Customer c1=new Customer();
//		c1.getCustomerName().setFname("Son");
//		c1.getCustomerName().setMname("Visha;");
//		c1.getCustomerName().setLname("Guptha");
//		c1.getPhno().add(2142353523l);
//		c1.getPhno().add(76575743l);
//		Customer c=new Customer();
//		c.getCustomerName().setFname("KashimShetty");
//		c.getCustomerName().setMname("Shwetha");
//		c.getCustomerName().setLname("Guptha");
//		c.getPhno().add(21424353523l);
//		c.getPhno().add(765765743l);
//		Car car=new Car();
//		car.setCarBrand("Swift");
//		car.setCarNumber(1234);
//		car.setCustomer(c);
//		
//		c.setC(car);
//		
//		Car car1=new Car();
//		car1.setCarBrand("M");
//		car1.setCarNumber(1235);
//		c.setC(car1);
//		//c.getC().setCarNumber(1234);
//		//c.getC().setCarBrand("Swift");
//		
//		try {
//		s.beginTransaction();
//		s.save(car);
//		s.save(car1);
//		s.save(c);
//		s.save(c1);
//		
//		s.getTransaction().commit();
//		}catch(Exception e) {
//			s.getTransaction().rollback();
//			System.out.println("exception " +e);
//		}
//		System.out.println("Done");
		
	}

}
