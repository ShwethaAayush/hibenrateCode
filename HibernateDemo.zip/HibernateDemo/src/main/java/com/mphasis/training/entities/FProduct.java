package com.mphasis.training.entities;

public class FProduct {

}
