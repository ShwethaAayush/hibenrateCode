package com.mphasis.training;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mphasis.training.daos.ProductDao;
import com.mphasis.training.entities.Product;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println("Product App");
     //   Product p=new Product(14, "Watch", 23234, 123,"fasttrack");
        
//        Configuration con=new Configuration().configure().addAnnotatedClass(Product.class);
//        SessionFactory sessionFactory=con.buildSessionFactory();
//        Session session=sessionFactory.openSession();
////        session.beginTransaction();
////        session.save(p);
////        session.getTransaction().commit();
//        Product p=(Product) session.get(Product.class, 14);
//        System.out.println(p);
//        System.out.println("done");
        Scanner sc=new Scanner(System.in);
        ProductDao pdao=new ProductDao();
        System.out.println("1.Add Product 2.Update product 3. Delete Product"
        		+ "4. Retrive Product 5. Retrive By cost 6.GetAll"); 
        switch(sc.nextInt()) {
        	case 6: System.out.println("List Of Products");
        	    pdao.retriveAll().forEach(p-> System.out.print(p));
        	    break;
        	case 7: System.out.println("Thank you");
        	System.exit(0);
        	default: System.out.println("invalid choice");
        }
        
        
    }
}
