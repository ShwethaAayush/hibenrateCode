package com.mphasis.training.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Customer{
@Id
@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="cust_seq")
@SequenceGenerator(sequenceName="customer_seq", allocationSize= 1, name="cust_seq")
private long id;

private CustomerName customerName=new CustomerName();

@ElementCollection
@CollectionTable(name="cus_phones" , joinColumns = @JoinColumn(name="cus_id"))
private List<Long> phno=new ArrayList<>();


@ManyToMany
private List<Car> cars=new ArrayList<>();

public List<Car> getCars() {
	return cars;
}

public void setCars(List<Car> cars) {
	this.cars = cars;
}

public List<Long> getPhno() {
	return phno;
}

public void setPhno(List<Long> phno) {
	this.phno = phno;
}

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public CustomerName getCustomerName() {
	return customerName;
}

public void setCustomerName(CustomerName customerName) {
	this.customerName = customerName;
}




}