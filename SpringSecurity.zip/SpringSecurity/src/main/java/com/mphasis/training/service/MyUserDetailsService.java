package com.mphasis.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.mphasis.training.daos.UserDao;
import com.mphasis.training.entities.User;



@Service
public class MyUserDetailsService implements UserDetailsService {

	@Autowired
	UserDao userDao;
	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		User user= userDao.findByUser(username);
		if(user == null)
			throw new UsernameNotFoundException("No User");
		return new UserPrincipal(user);
	}

}