package com.mphasis.training.service;

import com.mphasis.training.entities.User;

public interface UserService {
	public void save(User user);
	public User findById(int id);
	public User findByUser(String uname);
	public User findByUserAndPassword(String uname,String pass);
}
