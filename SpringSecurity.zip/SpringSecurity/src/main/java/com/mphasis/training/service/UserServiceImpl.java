package com.mphasis.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.mphasis.training.daos.UserDao;
import com.mphasis.training.entities.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDao userDao;

	@Autowired
	PasswordEncoder passwordEncoder;
	
	
	public void save(User user) {
		user.setPass(passwordEncoder.encode(user.getPass()));
		userDao.save(user);
	}

	
	public User findById(int id) {
		// TODO Auto-generated method stub
		return userDao.findById(id);
	}

	
	public User findByUser(String uname) {
		// TODO Auto-generated method stub
		return userDao.findByUser(uname);
	}

	
	public User findByUserAndPassword(String uname, String pass) {
		// TODO Auto-generated method stub
		return userDao.findByUserAndPassword(uname, pass);
	}

}
