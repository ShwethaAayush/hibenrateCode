package com.mphasis.training.daos;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.mphasis.training.entities.User;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	SessionFactory sf;
	
	
	@Override
	public void save(User user) {
		Session session=sf.openSession();
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();
		session.close();
	}

	@Override
	public User findById(int id) {
		Session session=sf.openSession();
		User user=(User) session.get(User.class, id);
		return user;
	}

	@Override
	public User findByUser(String uname) {
		Session session=sf.openSession();
		Query query=session.createQuery("FROM User u where u.uname=:uname");
		query.setParameter("uname", uname);
		User user=(User) query.uniqueResult();
		return user;
	}

	@Override
	public User findByUserAndPassword(String uname, String pass) {
		Session session=sf.openSession();
		Query query=session.createQuery("FROM User u where u.uname=:uname and password=:pass");
		query.setParameter("uname", uname);
		query.setParameter("pass", pass);
		User user=(User) query.uniqueResult();
		return user;
	}

}
