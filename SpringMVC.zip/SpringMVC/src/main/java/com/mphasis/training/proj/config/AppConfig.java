package com.mphasis.training.proj.config;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;

import com.mphasis.training.proj.repos.EmployeeRepo;
import com.mphasis.training.proj.repos.EmployeeRepoImpl;

@Configuration
@EnableAspectJAutoProxy
@ComponentScan(basePackages = "com.mphasis.training.proj")
public class AppConfig {
	
	//jdbcproperties --DriverManagerDataSource
	//hibernateproperties--LOcalSessionFactoryBean
	
	@Bean
	public DriverManagerDataSource getDataSource() {
		DriverManagerDataSource dataSource=new DriverManagerDataSource();
		dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		dataSource.setUsername("system");
		dataSource.setPassword("system");
		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		return dataSource;
	}
	
	
	@Bean
	public LocalSessionFactoryBean getSessionFactory() {
		LocalSessionFactoryBean sessionFactory=new LocalSessionFactoryBean();
		sessionFactory.setDataSource(getDataSource());
		Properties props=new Properties();
		props.put("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
		props.put("hibernate.hbm2ddl.auto", "update");
		props.put("hibernate.show_sql", "true");
		sessionFactory.setHibernateProperties(props);
		//sessionFactory.setAnnotatedClasses(Employee.class);
		sessionFactory.setPackagesToScan("com.mphasis.training.proj.pojos");
		return sessionFactory;
	}
	
//	@Bean
//	public EmployeeRepo getEmployeeRepo() {
//		EmployeeRepo employeeRepo= new EmployeeRepoImpl();
//		employeeRepo.setSessionFactory(getSessionFactory());
//		return employeeRepo;
//	}

}
