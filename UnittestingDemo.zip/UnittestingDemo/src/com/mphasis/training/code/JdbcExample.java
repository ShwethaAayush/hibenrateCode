package com.mphasis.training.code;

import java.sql.*;
public class JdbcExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
//            Class.forName("oracle.jdbc.driver.OracleDriver");
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
            Connection con=DriverManager.getConnection(  
                    "jdbc:oracle:thin:@localhost:1521:xe","java188","java188"); 
            System.out.println("Connection established......");
            String sql="select pid,cost,pname,qty from product";
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
            		ResultSet.CONCUR_UPDATABLE) ;

            ResultSet rs = st.executeQuery(sql);
            System.out.println("Contents of the last record: ");
            rs.last();
            int id=rs.getInt("PID")+1;
            rs.moveToInsertRow();
            rs.updateInt(1, id);
            rs.updateDouble(2, 89768.23);
            rs.updateString(3, "MIFit");
            rs.updateInt(4, 45);
            rs.insertRow();
            rs.beforeFirst();
      
          while(rs.next()) {
            System.out.print("ID: "+rs.getInt("PID")+", ");
            System.out.print("Cost: "+rs.getDouble("cost")+", ");
            System.out.print("Name: "+rs.getString("pname")+", ");
            System.out.print("qty: "+rs.getInt("qty")+", ");
            System.out.println("After Iteration");
          }
       con.close();
  } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      System.out.println(e);
  }  
  
	}

}
