package com.mphasis.training.testing;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runners.Parameterized.Parameters;

import com.mphasis.training.code.StringHelper;

public class StringHelperTest {
	 StringHelper helper;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	
	@Before
	public void setUp() throws Exception {
		helper=new StringHelper();
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("After each test method");
		helper=null;
	}

	@Test
	public void testTruncateInFirst2Positions() {	
		//String actualResult=helper.truncateInFirst2Positions("AABC");
		assertEquals("BC", helper.truncateInFirst2Positions("AABC"));
		assertEquals("BBC", helper.truncateInFirst2Positions("ABBC"));
		assertEquals("BNHG", helper.truncateInFirst2Positions("ABNHG"));
		assertEquals("VFG", helper.truncateInFirst2Positions("AVFG"));
	}
	
	@Test
	public void testTruncateInFirst2PositionsNegative() {	
		//String actualResult=helper.truncateInFirst2Positions("AABC");
		assertNotEquals("BC", helper.truncateInFirst2Positions("aaBC"));
		assertNotEquals("BBC", helper.truncateInFirst2Positions("aBBC"));
		assertNotEquals("BNHG", helper.truncateInFirst2Positions("aBNHG"));
		assertNotEquals("VFG", helper.truncateInFirst2Positions("aVFG"));
	}

	@Test
	public void testAreFirstAndLastTwoCharectersTheSame() {
		assertEquals(false, helper.areFirstAndLastTwoCharectersTheSame("SHWETHS"));
		assertFalse(helper.areFirstAndLastTwoCharectersTheSame("SHWETHS"));
		assertTrue(helper.areFirstAndLastTwoCharectersTheSame("MEGHAME"));
		assertTrue(helper.areFirstAndLastTwoCharectersTheSame("SOMESO"));
	}
	
	
	@Test
	public void testArray() {
		int[] numbers= {12,3,4,56,1};
		int[] expected = {1,3,4,12,56};
		Arrays.sort(numbers);
		assertArrayEquals(numbers, expected);
	}

	
	@Test(expected = NullPointerException.class)
     public void testNull() {
    	 int[] numbers=null;
    	 Arrays.sort(numbers);
     }	
	
	@Test(timeout = 300)
	public void testPerformance() {
		int array[]= {12,13,4,78};
		for(int i=0;i<=10000000;i++) {
			array[0]=i;
			Arrays.sort(array);
		}
	}
	
	@Parameters
	public static Collection<String[]> testConditions(){
		String expectedResult[][] = {{"AACD","CD"},{"ACD","CD"}};
		return Arrays.asList(expectedResult);
	}
	
	
	
	
	
	
	
	
}
