package com.mphasis.training.testing;

import static org.junit.Assert.*;

import org.junit.Test;

import com.mphasis.training.code.Calculator;

public class SampleTest {

	@Test
	public void test() {
		//fail("Not yet implemented");
	}
	
	@Test
	public void testArray() {
		Calculator cal=new Calculator();
		assertEquals(10, cal.add(4, 6));
	}

}
