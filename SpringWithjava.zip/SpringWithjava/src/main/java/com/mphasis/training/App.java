package com.mphasis.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mphasis.training.config.AppConfig;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //BeanFactory factory=new XmlBeanFactory(new ClassPathResource("application.xml"));
    	//ApplicationContext context=new ClassPathXmlApplicationContext("application.xml");
       ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
       Address add=context.getBean(Address.class);
       add.setStreet("MNNagar");
       add.setCity("Ban");
       add.setPincode(453543);
       
    	Employee e=(Employee) context.getBean(Employee.class);
        e.setEmpid(123);
        e.setEname("Shwetha");
        e.setAddress(add);
        
       
        
        Address add1=context.getBean(Address.class);
        add1.setStreet("RRNagar");
        add1.setCity("Ban");
        add1.setPincode(493543);
    
        System.out.println(e);
        System.out.println(add+" "+add1);
    
        
        
    }
}
