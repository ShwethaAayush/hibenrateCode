package com.mphasis.training.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.mphasis.training.Address;
import com.mphasis.training.Employee;

@Configuration
public class AppConfig {
//	<bean id="" class>
	@Bean
	@Scope("prototype")
	public Address getAddress() {
		return new Address();
	}
	
	
	@Bean
	public Employee getEmployee() {
		return new Employee();
	}
}
//@Configuration
//@Component --> @Repository
//@Service
//@Controller, @RestController
//@Aspect