package com.mphasis.training.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.training.entities.Employee;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.repos.EmployeeRepo;

@Service
public class EmployeeBoImpl implements EmployeeBo {
	@Autowired
	EmployeeRepo employeeRepo;

	

	@Override
	public List<Employee> getAllEmployee()throws BuisnessException{
		List<Employee> employees=employeeRepo.retiveAllEmployee();
		if(employees.isEmpty()) {
			throw new BuisnessException("No Employees Found");
		}
		return  employees;
	}

	@Override
	public Employee getEmployeeById(int id)throws BuisnessException {
		Employee e=employeeRepo.retriveEmployeeById(id);
		if(e.getEmpid()==0) {
			throw new BuisnessException("NO employee for requested id");
		}
		return e;
	}

	@Override
	public int addEmployee(Employee e)throws BuisnessException {
		int i=0;
		if(e.getEmpid()>=0  && e.getEmpid()< 999) {
			if(e.getEname().matches("[a-zA-Z]{3,10}")) {
				if(e.getSalary()>20000 && e.getSalary()<80000) {
					i=employeeRepo.addEmployee(e);
				}else {
					throw new BuisnessException("invalid salary");
				}
			}else {
				throw new BuisnessException("invalid Name, name allows only 3 to 10 letters");
			}
		}else {
			throw new BuisnessException("invalid employee ID");
		}
		return i;
	}

	@Override
	public int updateEmployee(Employee e) {
		// TODO Auto-generated method stub
		return employeeRepo.updateEmployee(e);
	}

	@Override
	public int removeEmployee(int id) {
		// TODO Auto-generated method stub
		return employeeRepo.deleteEmployee(id);
	}

	@Override
	public List<Employee> sortEmployeeByName() {
		// TODO Auto-generated method stub
		List<Employee> employes=employeeRepo.retiveAllEmployee();
		employes.sort((e1,e2)-> e1.getEname().compareTo(e2.getEname()));
		return employes;
	}

	@Override
	public List<Employee> getEmployeeByName(String name) {
		// TODO Auto-generated method stub
//		List<Employee> eNames=new ArrayList<>();
//		List<Employee> employes=employeeRepo.retiveAllEmployee();
//		for(Employee e:employes) {
//			if(e.getEname().equals(name)) {
//				eNames.add(e);
//			}
//		}
//		return eNames;
		return employeeRepo.retiveAllEmployee()
				.stream().filter(e-> e.getEname().equals(name))
				.collect(Collectors.toList());
	}

	@Override
	public List<Employee> getEmployeeBySalary(double salary) {
		List<Employee> employes=employeeRepo.retiveAllEmployee();
		employes.sort((e1,e2)-> (int) (e1.getSalary()-e2.getSalary()));
		return employes;
	}

	@Override
	public Employee getEmployeeWithHighestExperience() {
		// TODO Auto-generated method stub
		return null;
	}

}
