package com.mphasis.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.training.entities.Employee;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.services.EmployeeBo;

@Controller
public class DemoController {
	
	@Autowired
	private EmployeeBo employeeBo;
	
	//get
	@RequestMapping("/login")
	public String loginPage() {
		System.out.println("login code");
		return "login";
	}
	//POST
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView getlogin(@RequestParam("uname")String uname,
			@RequestParam("pwd")String pass) {
		System.out.println("username and password "+uname);
		ModelAndView mv=new ModelAndView();
		if(uname.contains("mla") && pass.contains("mph")) {
			mv.setViewName("welcome");
			mv.addObject("message", uname);
		}else {
			mv.setViewName("login");
			mv.addObject("message", "Invalid Credentials");	
		}
		return mv;
	}
	
	
	@RequestMapping("/employees")
	public ModelAndView getEmployees() {
	ModelAndView mv=new ModelAndView();
	try {
		mv.addObject("listEmployee", employeeBo.getAllEmployee());
		mv.setViewName("employees");
	}catch(BuisnessException e) {
		mv.addObject("error", e.getMessage());
		mv.setViewName("employees");
	}
		return mv;
	}
	
	@RequestMapping("/addEmployee")
	public String addEmployeePage(Model model) {
		model.addAttribute("employee", new Employee());
		return "addEmployee";		
	}
	
	
	@RequestMapping(value="/add/Employee", method = RequestMethod.POST)
	public String  addEMployee(@ModelAttribute Employee employee,Model model) {
		System.out.println("add employee called");
		try {
		if(employee.getEmpid()==0) {
			
				employeeBo.addEmployee(employee);
			
		}else {
			employeeBo.updateEmployee(employee);
		}
		return "redirect:/employees";
	} catch (BuisnessException e) {
		model.addAttribute("error", e.getMessage());
		return "addEmployee";
	}
	}
	
	@RequestMapping("/edit/{eid}")
	public String editEMployee(@PathVariable("eid")int id, Model model ) {
		System.out.println("edit called");
		Employee e;
		try {
			e = employeeBo.getEmployeeById(id);
			model.addAttribute("employee",e);
		} catch (BuisnessException e1) {
			e1.printStackTrace();
		}
		
		return "addEmployee";
	}
	
	@RequestMapping("/delete/{eid}")
	public String deleteEmployee(@PathVariable("eid")int id) {
		try {
			employeeBo.removeEmployee(id);
		} catch (BuisnessException e) {
			e.printStackTrace();
		}
		return "redirect:/employees";
	}
	
}
