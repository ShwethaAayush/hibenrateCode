package com.mphasis.training.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.training.entities.Employee;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.services.EmployeeBo;

@Controller
public class DemoController {
	
	@Autowired
	private EmployeeBo employeeBo;
	
	//get
	@RequestMapping("/login")
	public String loginPage() {
		System.out.println("login code");
		return "login";
	}
	//POST
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView getlogin(@RequestParam("uname")String uname,
			@RequestParam("pwd")String pass, HttpServletRequest request) {
		System.out.println("username and password "+uname);
		HttpSession session=request.getSession();
		ModelAndView mv=new ModelAndView();
		if(uname.contains("mla") && pass.contains("mph")) {
			mv.setViewName("welcome");
			session.setAttribute("sname", uname);
			mv.addObject("message", uname);
		}else {
			mv.setViewName("login");
			mv.addObject("message", "Invalid Credentials");	
		}
		return mv;
	}
	
	
	@RequestMapping("/employees")
	public ModelAndView getEmployees() {
	ModelAndView mv=new ModelAndView();
	try {
		mv.addObject("listEmployee", employeeBo.getAllEmployee());
		mv.setViewName("employees");
	}catch(BuisnessException e) {
		mv.addObject("error", e.getMessage());
		mv.setViewName("employees");
	}
		return mv;
	}
	
	@RequestMapping("/addEmployee")
	public String addEmployeePage(Model model) {
		model.addAttribute("employee", new Employee());
		return "addEmployee";		
	}
	
	
	@RequestMapping(value="/add/Employee", method = RequestMethod.POST)
	public String  addEMployee( @ModelAttribute Employee employee,Model model) {
		System.out.println("add employee called");
//		if(br.hasErrors()) {
//			return "addEmployee";
//		}else {
		try {
		if(employee.getEmpid()==0) {
			
				employeeBo.addEmployee(employee);
			
		}else {
			employeeBo.updateEmployee(employee);
		}
		return "redirect:/employees";
		
	} catch (BuisnessException e) {
		model.addAttribute("error", e.getMessage());
		return "addEmployee";
	//}
	}
	}
	
	@RequestMapping("/edit/{eid}")
	public String editEMployee(@PathVariable("eid")int id, Model model ) {
		System.out.println("edit called");
		Employee e;
		try {
			e = employeeBo.getEmployeeById(id);
//			Date d=e.getDoj();
//			String s=d.toString();
//			try {
//				Date sd=new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss").parse(s);
//				String sd1=new SimpleDateFormat("dd-MMM-yyyy").format(sd);
//				e.setDoj(sd);
				System.out.println("code in");
				model.addAttribute("employee",e);
//			} catch (ParseException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
			
		} catch (BuisnessException e1) {
			e1.printStackTrace();
		}
		
		return "addEmployee";
	}
	
	@RequestMapping("/delete/{eid}")
	public String deleteEmployee(@PathVariable("eid")int id) {
		try {
			employeeBo.removeEmployee(id);
		} catch (BuisnessException e) {
			e.printStackTrace();
		}
		return "redirect:/employees";
	}
	
	@RequestMapping("/logout")
	public String getLogout(HttpSession session) {
		session.removeAttribute("sname");
		session.invalidate();
		return "login";
	}
}
