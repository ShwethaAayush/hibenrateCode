package com.mphasis.training.proj.repos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.training.proj.pojos.Employee;

public class EmployeeRepoImpl implements EmployeeRepo {
	
	List<Employee> employees=new ArrayList<>();
	
	public EmployeeRepoImpl() {
		employees.add(new Employee(1, "Meghana", 2342332, LocalDate.of(2019, 10, 05)));
		employees.add(new Employee(2, "Vishal", 2542332, LocalDate.of(2019, 10, 05)));
		employees.add(new Employee(3, "Shodhan", 1342332, LocalDate.of(2019, 10, 05)));
		employees.add(new Employee(4, "Uday", 2348332, LocalDate.of(2019, 10, 05)));
		employees.add(new Employee(5, "Swathi", 2742332, LocalDate.of(2019, 10, 05)));
		employees.add(new Employee(6, "Hema", 2342332, LocalDate.of(2019, 10, 05)));
		employees.add(new Employee(7, "Yeshu", 2342332, LocalDate.of(2019, 10, 05)));
		employees.add(new Employee(8, "Prem", 2342332, LocalDate.of(2019, 10, 05)));
		employees.add(new Employee(9, "Deepak", 2342332, LocalDate.of(2019, 10, 05)));
		employees.add(new Employee(10, "Supriya", 2342332, LocalDate.of(2019, 10, 05)));	
	}

	@Override
	public List<Employee> retiveAllEmployee() {
		return employees;
	}

	@Override
	public Employee retriveEmployeeById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int addEmployee(Employee e) {
		// TODO Auto-generated method stub
		employees.add(e);
		return 1;
	}

	@Override
	public int updateEmployee(Employee e) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

}
