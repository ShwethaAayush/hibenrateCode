package com.mphasis.training.proj.repos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.training.proj.pojos.Employee;

@Repository
public class EmployeeRepoImpl implements EmployeeRepo {

	@Autowired
	SessionFactory sessionFactory;
	

	@Override
	public List<Employee> retiveAllEmployee() {
		List<Employee> employees=new ArrayList<>();
		Session session=sessionFactory.openSession();
		employees=session.createCriteria(Employee.class).list();
		session.close();
		return employees;
	}

	@Override
	public Employee retriveEmployeeById(int id) {
		Session session=sessionFactory.openSession();
		Employee employee=(Employee) session.get(Employee.class, id);
		session.close();
		return employee;
	}

	@Override
	public int addEmployee(Employee employee) {
		int i=0;
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		return i;
	}

	@Override
	public int updateEmployee(Employee e) {
		int i=0;
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		System.out.println(e.getDoj()+" "+e.getEname()+"Dao code");
		session.update(e);
		session.getTransaction().commit();
		session.close();
		return i;
	}

	@Override
	public int deleteEmployee(int id) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		Employee e= (Employee)session.get(Employee.class, id);
		session.delete(e);
		session.getTransaction().commit();
		session.close();
		return 0;
	}

}
