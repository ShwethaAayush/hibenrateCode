package com.mphasis.training.proj.config;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.mphasis.training.proj.pojos.Employee;

//logging
@Aspect
@Component
public class AspectHelper {
	
	@Before("execution(* com.mphasis.training.proj.repos.*.*(..))")
	public void beforeMethod(JoinPoint joinPoint) {
		System.out.println("Before Advice is calling "+joinPoint.getSignature().getName());
	}

	@After("execution(* com.mphasis.training.proj.*.*.*(..))")
	public void aeforeMethod(JoinPoint joinPoint) {
		System.out.println("after Advice is calling"+joinPoint.getSignature().getName());
	}
	
	@AfterThrowing(value="execution(* com.mphasis.training.proj.services.*.*(..))", throwing = "ex")
	public void logafterThrows(JoinPoint jp,Exception ex) throws Throwable{
		System.out.println(ex.getMessage()+" after execption"+jp.getSignature());
	}
	
	@AfterReturning(value = "execution(* com.mphasis.training.proj.services.*.*(..))", 
			returning ="employee")
	public void logAfterReturns(JoinPoint joinPoint, Employee employee) {
		System.out.println("After return "+joinPoint.getSignature().getName()+" "
	+joinPoint.getArgs());
		System.out.println(employee);	
	}
	
//	@Around("execution(* com.mphasis.training.proj.*.*.*(..))")
//	public void logAround(ProceedingJoinPoint pj) {
//		System.out.println("around called " +pj.getSignature());
//		try {
//		pj.proceed();
//		}catch(Throwable t){
//			System.out.println(t.getMessage());
//		}finally {}
//		System.out.println("around advice");
//		
//	}
}

