package com.mphasis.training.proj.pojos;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Employee implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int empid;
//	@NotNull(message="name is manadatory")
//	@Size(min = 3, max=20, message="name should be within 3 to 20")
//	//@Column(length=20)
	private String ename;
	private double salary;

	private Date doj;
	public Employee() {
		
	}	
	public Employee(int empid, String ename, double salary, Date doj) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.salary = salary;
		this.doj = doj;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	@Override
	public String toString() {
		return "empid=" + empid + ", ename=" + ename + ", salary=" + salary + ", doj=" + doj ;
	}
	
	
	

}
