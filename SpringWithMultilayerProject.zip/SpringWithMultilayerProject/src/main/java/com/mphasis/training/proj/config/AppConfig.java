package com.mphasis.training.proj.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.mphasis.training.proj")
public class AppConfig {

}
