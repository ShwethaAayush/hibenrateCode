package com.mphasis.training.proj.repos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.mphasis.training.proj.pojos.Employee;
import com.mphasis.training.proj.util.DbUtil;

@Repository
public class EmployeeRepoImpl implements EmployeeRepo {

	Connection con=null;
	
	public EmployeeRepoImpl() {
		con=DbUtil.openConnection();
	}

	@Override
	public List<Employee> retiveAllEmployee() {
		List<Employee> employees=new ArrayList<>();
		try {
		String sql="select * from employee";
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			Employee e1=new Employee();
			e1.setEmpid(rs.getInt(1));
			e1.setEname(rs.getString(2));
			e1.setSalary(rs.getDouble(3));
			java.sql.Date sqlDate=rs.getDate(4);
			LocalDate ld=sqlDate.toLocalDate();
			e1.setDoj(ld);
			employees.add(e1);
		}
		}catch(SQLException e) {
			e.printStackTrace();
		}	
		return employees;
	}

	@Override
	public Employee retriveEmployeeById(int id) {
		Employee employee=new Employee();
		try {
			String sql="select * from employee where empid=?";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				employee.setEmpid(rs.getInt(1));
				employee.setEname(rs.getString(2));
				employee.setSalary(rs.getDouble(3));
				java.sql.Date sqlDate=rs.getDate(4);
				LocalDate ld=sqlDate.toLocalDate();
				employee.setDoj(ld);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return employee;
	}

	@Override
	public int addEmployee(Employee employee) {
		int i=0;
		try {
			String sql="insert into employee values(?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, employee.getEmpid());
			pst.setString(2, employee.getEname());
			pst.setDouble(3, employee.getSalary());
			LocalDate ld=employee.getDoj();
			pst.setDate(4, java.sql.Date.valueOf(ld));
			
			i=pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updateEmployee(Employee e) {
		int i=0;
		try {
			String sql="update employee set salary=? where empid=?";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setDouble(1, e.getSalary());
			pst.setInt(2, e.getEmpid());
			i=pst.executeUpdate();
			
		}catch (SQLException ex) {
			ex.printStackTrace();
		}
		return i;
	}

	@Override
	public int deleteEmployee(int id) {
		int i=0;
		try {
		String sql="delete from employee where empid=?";
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, id);
		i=pst.executeUpdate();
		}catch (SQLException ex) {
			ex.printStackTrace();
		}
		return i;
	}

}
