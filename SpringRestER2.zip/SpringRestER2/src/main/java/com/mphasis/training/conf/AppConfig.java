package com.mphasis.training.conf;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;


@Configuration
@EnableAspectJAutoProxy
@EnableWebMvc
@ComponentScan(basePackages="com.mphasis.training")
public class AppConfig {

	
	@Bean
	public DriverManagerDataSource getDataSource() {
		DriverManagerDataSource ds=new DriverManagerDataSource();
		ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		ds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		ds.setUsername("project");
		ds.setPassword("project");
		return ds;
	}

	@Bean
	public LocalSessionFactoryBean getSessionFactory() {
		LocalSessionFactoryBean sessionFactory=new LocalSessionFactoryBean();
		sessionFactory.setDataSource(getDataSource());
		Properties props=new Properties();
		props.put("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
		props.put("hibernate.hbm2ddl.auto", "create");
		props.put("hibernate.show_sql", "true");
		props.put("hibernate.format_sql", "true");
		sessionFactory.setHibernateProperties(props);
		//sessionFactory.setAnnotatedClasses(Product.class);
		sessionFactory.setPackagesToScan("com.mphasis.training.entities");
		return sessionFactory;	
	}
	
	
//	@Bean
//	public MultipartResolver getMultipartResolver() {
//		CommonsMultipartResolver multipartResolver=new CommonsMultipartResolver();
//		multipartResolver.setMaxUploadSize(100000);
//		return multipartResolver;
//	}

}
