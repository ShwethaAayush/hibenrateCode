package com.mphasis.training.controller;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.mphasis.training.entities.Department;
import com.mphasis.training.entities.Employee;
import com.mphasis.training.entities.Job;
import com.mphasis.training.entities.Location;
import com.mphasis.training.service.DepartmentService;
import com.mphasis.training.service.EmployeeService;
import com.mphasis.training.service.JobService;
import com.mphasis.training.service.LocationService;

@RestController
@RequestMapping("/deps")
public class AdminController {
	
	@Autowired
	DepartmentService departmentService;

	@Autowired
	JobService jobService;
	
	
	@Autowired
	LocationService locationService;
	
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping( produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getDepartments(){
		List<Department> departments= departmentService.getAll();
		//ResponseEntity<?> responseEntity=new ResponseEntity<?>(departments,HttpStatus.OK);
		return ResponseEntity.ok().body(departments);
	}
	
	
	@RequestMapping( value="/job", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> addjob(@RequestBody Job job){
		jobService.addJob(job);
		final URI location = MvcUriComponentsBuilder.fromController(getClass())
				.path("/job/{id}")
				.buildAndExpand(job.getJcode())
				.toUri();
		return ResponseEntity.created(location).body(job);
	}
	
	
	@RequestMapping(value="/job/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getJob(@PathVariable("id")String id){
		Job job=jobService.getJobById(id);
		return ResponseEntity.ok().body(job);
	}
	
	
	@RequestMapping( value="/loc", method=RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> addLocation(@RequestBody Location loc){
		locationService.addLocation(loc);
		final URI location = MvcUriComponentsBuilder.fromController(getClass())
				.path("/loc/{id}")
				.buildAndExpand(loc.getLid())
				.toUri();
		return ResponseEntity.created(location).body(loc);
	}
	
	
	@RequestMapping(value="/loc/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLocation(@PathVariable("id")String id){
	Location loc=locationService.getLocationById(id);
		return ResponseEntity.ok().body(loc);
	}
	
	@RequestMapping(value="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getDepartment(@PathVariable("id")int id){
		Department department= departmentService.getDepartmentById(id);
		return ResponseEntity.ok().body(department);
	}
	
	
	
	@RequestMapping(method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE, 
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> addDepartment(@RequestBody Department d){
		departmentService.addDepartment(d);
		final URI location = MvcUriComponentsBuilder.fromController(getClass())
				.path("/{id}")
				.buildAndExpand(d.getDid())
				.toUri();
		return ResponseEntity.created(location).body(d);
	}
	
	@RequestMapping(value="/empbyname/{like}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> getEmployeeByName(@PathVariable("like")String like){
		List<Employee> e=null;
		try {
			e=employeeService.getEmployeeByName(like);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return e;
	}
	
	
	@RequestMapping(value="/departments",method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE)
	public void updateDepartment(@RequestBody Department d){
		try {
			departmentService.updateDepartment(d);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@RequestMapping(value="/department/{did}",method=RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
	public void deleteDepartment(@PathVariable("did") int did){
		try {
			departmentService.deleteDepartment(did);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@RequestMapping(value="/locations",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Location> viewLocation(){
		List<Location> e=null;
		try {
			e=locationService.getAll();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return e;
	}


	@RequestMapping(value="/locations",method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE)
	public void updateLocation(@RequestBody Location l){
		try {
			locationService.updateLocation(l);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@RequestMapping(value="/location/{lid}",method=RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
	public void deleteLocation(@PathVariable("lid") int lid){
		try {
			locationService.deleteLocation(lid);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	
	
	@RequestMapping(value="/location/{lname}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLocationByName(@PathVariable("lname")String lname){
		List<Employee> employees=employeeService.getEmployeeByLocation(lname);
		return ResponseEntity.ok().body(employees);
	}
	
	
	@RequestMapping(value="/doj/{doj}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getDOj(@PathVariable("doj")String doj){
		 List<Employee> employees=employeeService.getAll().stream()
				 .filter(a->a.getDoj().equals(doj)).collect(Collectors.toList());
		 return ResponseEntity.ok().body(employees);
		
		
	}
	
	
}
