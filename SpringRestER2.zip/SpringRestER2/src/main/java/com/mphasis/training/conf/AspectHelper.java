package com.mphasis.training.conf;

import java.util.Arrays;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AspectHelper {
	Logger logger=Logger.getLogger(AspectHelper.class); 
	
	@Pointcut("execution(* com.mphasis.training.*.*.*(..))")
	public void getAll() {}
	
	@Before("getAll()")
	public void beforeMethod(JoinPoint jp) {
		logger.debug(jp.getSignature());
		System.out.println("Before the Method " + jp.getSignature().getName());
		System.out.println(Arrays.toString(jp.getArgs()));
	}
	
	@After("getAll()")
	public void afterMethod(JoinPoint jp) {
		logger.debug(jp.getSignature());
		System.out.println("After the Method " + jp.getSignature().getName());
		System.out.println(Arrays.toString(jp.getArgs()));
	}
	
	@AfterThrowing(pointcut="execution(* com.mphasis.training.*.*.*(..))")
	public void afterThrowingMethod(JoinPoint jp) {
		System.out.println("After Throwing the Method " + jp.getSignature().getName());
		System.out.println(Arrays.toString(jp.getArgs()));
	}
}
