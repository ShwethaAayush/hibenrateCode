package com.mphasis.training.daos;

import com.mphasis.training.entities.User;

public interface UserDao {
	
	public void save(User user);
	public User findById(int id);
	public User findByUser(String uname);
	public User findByUserAndPassword(String uname,String pass);

}
