package com.mphasis.training.daos;

import java.util.List;

import com.mphasis.training.entities.Person;

public interface PersonDao {

	public void addPerson(Person p);
	public Person getPersonById(int id);
	public List<Person> getPersons();
	
	
}
