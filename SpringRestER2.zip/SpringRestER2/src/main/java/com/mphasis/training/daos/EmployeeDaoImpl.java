package com.mphasis.training.daos;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.training.entities.Department;
import com.mphasis.training.entities.Employee;
import com.mphasis.training.entities.Job;
import com.mphasis.training.entities.Location;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	SessionFactory sf;

	public void addEmployee(Employee e) {
		Session session=sf.openSession();
		session.beginTransaction();
		session.save(e);
		session.getTransaction().commit();
		session.close();
	}

	public void updateEmployee(Employee e) {
		Session session=sf.openSession();
		session.beginTransaction();
		session.saveOrUpdate(e);
		session.getTransaction().commit();
		session.close();
	}

	public void deleteEmployee(int eid) {
		Session session=sf.openSession();
		session.beginTransaction();
		Employee e=(Employee)session.get(Employee.class, eid);
		session.delete(e);
		session.getTransaction().commit();
		session.close();		
	}

	public Employee getEmployeeById(int eid) {
		Session session=sf.openSession();
		Employee e=(Employee)session.get(Employee.class, eid);
		return e;
	}

	public List<Employee> getAll() {
		Session session=sf.openSession();
		@SuppressWarnings("unchecked")
		List<Employee> e=session.createCriteria(Employee.class).list();
		return e;
	}

	public List<Employee> getEmployeeByDept(int did) {
		Session session=sf.openSession();
		Department dept=(Department) session.get(Department.class, did);
		@SuppressWarnings("unchecked")
		List<Employee> e=session.createCriteria(Employee.class).add(Restrictions.eq("dept", dept)).list();
		return e;
	}

	public List<Employee> getEmployeeByLoc(int lid) {
		//List<Employee> employeesByLoc=new ArrayList<>();
		Session session=sf.openSession();
		Location loc=(Location)session.get(Location.class, lid);
		@SuppressWarnings("unchecked")
		List<Department> dept=session.createCriteria(Department.class).add(Restrictions.eq("loc",loc)).list();	
		List<Employee> e=session.createCriteria(Employee.class).add(Restrictions.in("dept",dept)).list();	
		return e;
	}

	public List<Employee> getEmployeeByJob(int jid) {
		Session session=sf.openSession();
		Job job=(Job) session.get(Job.class, jid);
	
		List<Employee> e=session.createCriteria(Employee.class).add(Restrictions.eq("job", job)).list();
		return e;
	}

	public List<Employee> getEmployeeByName(String like) {
		Session session=sf.openSession();
		like=like+"%";
		@SuppressWarnings("unchecked")
		List<Employee> e=session.createCriteria(Employee.class)
		.add(Restrictions.ilike("ename", like)).list();
		return e;
	}
	
	public List<Employee> getEmployeeByLocation(String lname){
		
		Session session=sf.openSession();
		TypedQuery<Employee> query= session.createQuery("FROM Employee e WHERE e.dept.loc.lname =:lname"); 
		query.setParameter("lname", lname);
		List<Employee> employees=query.getResultList();
		return employees;
	}

	@Override
	public List<Employee> getByJcodeAndSalesDepartment(String jcode, String dname) {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
		TypedQuery<Employee> query= session.createQuery("FROM Employee e WHERE e.job.jcode= :jcode and e.dept.dname=:dname");
		query.setParameter("jcode", jcode);
		query.setParameter("dname", dname);
		return query.getResultList();
	}

	@Override
	public List<Employee> getEnameDnameLname() {
		Session session=sf.openSession();
		TypedQuery<Employee> query= session.createQuery("FROM Employee"); 
		return query.getResultList();
	}

	@Override
	public List<Employee> getByDOJ(String doj) {
		Session session=sf.openSession();
		TypedQuery<Employee> query= session.createQuery("FROM Employee e where e.doj=:doj");
		query.setParameter("doj", doj);
		return query.getResultList();
	}

	@Override
	public List<Employee> getByDojAndSalary(String doj, String name) {
		Session session=sf.openSession();
		TypedQuery<Employee> query=session.createQuery("FROM Employee e where e.ename = :name");
		query.setParameter("name", name);
		Employee e = query.getSingleResult();
		double sriniSalary = e.getSalary();
		TypedQuery<Employee> query1=session.createQuery("FROM Employee e where e.doj = :doj and salary > :sriniSalary");
		query1.setParameter("doj", doj);
		query1.setParameter("sriniSalary", sriniSalary);
		return query1.getResultList();
	}
}
