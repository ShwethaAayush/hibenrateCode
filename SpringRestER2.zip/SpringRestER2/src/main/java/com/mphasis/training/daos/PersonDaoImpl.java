package com.mphasis.training.daos;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.training.entities.Employee;
import com.mphasis.training.entities.Person;

@Repository
public class PersonDaoImpl implements PersonDao {

	
	@Autowired
	private SessionFactory sf;
	
	@Override
	public void addPerson(Person p) {
		Session session=sf.openSession();
		session.beginTransaction();
		session.save(p);
		session.getTransaction().commit();
		session.close();
	}

	@Override
	public Person getPersonById(int id) {
		Session session=sf.openSession();
		Person p=(Person)session.get(Person.class, id);
		return p;
	}

	@Override
	public List<Person> getPersons() {
		Session session=sf.openSession();
		@SuppressWarnings("unchecked")
		List<Person> ps=session.createCriteria(Person.class).list();
		return ps;
	}

}
