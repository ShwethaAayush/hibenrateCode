package com.mphasis.training.repos;

import java.util.List;

import com.mphasis.training.entities.Employee;

public interface EmployeeRepo {
	
	public List<Employee> retiveAllEmployee();
	public Employee retriveEmployeeById(int id);
	public int addEmployee(Employee e);
	public int updateEmployee(Employee e);
	public int deleteEmployee(int id);
	

}
