package com.mphasis.training.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.mphasis.training.entities.Employee;
import com.mphasis.training.exceptions.BuisnessException;
import com.mphasis.training.services.EmployeeBo;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	@Autowired
	EmployeeBo employeeBo;
	
	@RequestMapping(value="/employee/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getEmployee(@PathVariable("id")int id){
		Employee e=null;
		ResponseEntity<?> responseEntity=null;
		try {
			e=employeeBo.getEmployeeById(id);
			responseEntity= new ResponseEntity<Employee>(e, HttpStatus.OK);
		}catch (NullPointerException e1) {
			responseEntity= new ResponseEntity<Error>(HttpStatus.NOT_FOUND);
		}catch(BuisnessException e2) {
			responseEntity= new ResponseEntity<Error>(HttpStatus.NOT_ACCEPTABLE);
		}
		return responseEntity;
	}
	
	
	@RequestMapping(value="/employees", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Employee>> getEmployees(){
		ResponseEntity<List<Employee>> responseEntity=null;
		try {
			List<Employee> employees=employeeBo.getAllEmployee();
			responseEntity = new ResponseEntity<List<Employee>>(employees,HttpStatus.OK);
		} catch (BuisnessException e) {
		 responseEntity = new ResponseEntity<List<Employee>>(HttpStatus.NO_CONTENT);	
		}
		return responseEntity;
	}
	
	
	@RequestMapping(value="/employee",method=RequestMethod.POST,
			produces=MediaType.APPLICATION_JSON_VALUE,
			consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> addEmployee(@RequestBody Employee e) throws BuisnessException{
		ResponseEntity<?> responseEntity=null;
		employeeBo.addEmployee(e);
		responseEntity =new ResponseEntity<>(e, HttpStatus.CREATED);
		return responseEntity;
	}
	
	@RequestMapping(value="/employee/{id}",method=RequestMethod.DELETE)
	public ResponseEntity<?> deleteEmployee(@PathVariable("id")int id)throws BuisnessException{
		ResponseEntity<?> responseEntity=null;
		employeeBo.removeEmployee(id);
		responseEntity =new ResponseEntity<>(HttpStatus.OK);
		return responseEntity;
	}
	
	
	@RequestMapping(value="/employee",method=RequestMethod.PATCH,
			produces=MediaType.APPLICATION_JSON_VALUE,
			consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateEmployee(@RequestBody Employee e) throws BuisnessException{
		ResponseEntity<?> responseEntity=null;
		employeeBo.updateEmployee(e);
		responseEntity =new ResponseEntity<>(e, HttpStatus.CREATED);
		return responseEntity;
	}
	
	
		

}
