package com.demo.dao;

import java.util.List;

import com.demo.model.DepartmentVO;
import com.demo.model.EmployeeVO;

public interface EmployeeDAO 
{
	public void addEmployee(EmployeeVO employeeVo);
	public List<EmployeeVO> getAllEmployees();
	public List<DepartmentVO> getDepartments();
}