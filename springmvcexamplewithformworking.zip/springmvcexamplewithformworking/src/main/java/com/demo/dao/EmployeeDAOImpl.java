package com.demo.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.demo.model.DepartmentVO;
import com.demo.model.EmployeeVO;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	public List<EmployeeVO> getAllEmployees() 
	{
		List<EmployeeVO> employees = new ArrayList<EmployeeVO>();
		
//		EmployeeVO vo1 = new EmployeeVO();
//		vo1.setId(1);
//		vo1.setFirstName("Lokesh");
//		vo1.setLastName("Gupta");
//		employees.add(vo1);
//		
//		EmployeeVO vo2 = new EmployeeVO();
//		vo2.setId(2);
//		vo2.setFirstName("Raj");
//		vo2.setLastName("Kishore");
//		employees.add(vo2);
		
		Session session=sessionFactory.openSession();
		employees= session.createCriteria(EmployeeVO.class).list();
		
		return employees;
	}
	
	public void addEmployee(EmployeeVO employeeVo) {
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(employeeVo);
		session.getTransaction().commit();
	}

	public List<DepartmentVO> getDepartments() {
List<DepartmentVO> departments = new ArrayList<DepartmentVO>();
		
//		EmployeeVO vo1 = new EmployeeVO();
//		vo1.setId(1);
//		vo1.setFirstName("Lokesh");
//		vo1.setLastName("Gupta");
//		employees.add(vo1);
//		
//		EmployeeVO vo2 = new EmployeeVO();
//		vo2.setId(2);
//		vo2.setFirstName("Raj");
//		vo2.setLastName("Kishore");
//		employees.add(vo2);
		
		Session session=sessionFactory.openSession();
		departments= session.createCriteria(DepartmentVO.class).list();
		
		return departments;
	}
}