package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.EmployeeDAO;
import com.demo.model.DepartmentVO;
import com.demo.model.EmployeeVO;

@Service
public class EmployeeManagerImpl implements EmployeeManager {

	@Autowired
	EmployeeDAO dao;
	
	public List<EmployeeVO> getAllEmployees() 
	{
		return dao.getAllEmployees();
	}
	
	public void addEmployee(EmployeeVO employee) {
		dao.addEmployee(employee);
	}

	public List<DepartmentVO> getDepartments() {
		
		return dao.getDepartments();
	}
}
