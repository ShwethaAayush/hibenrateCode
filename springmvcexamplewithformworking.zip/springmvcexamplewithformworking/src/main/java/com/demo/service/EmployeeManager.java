package com.demo.service;

import java.util.List;

import com.demo.model.DepartmentVO;
import com.demo.model.EmployeeVO;

public interface EmployeeManager 
{
	public List<EmployeeVO> getAllEmployees();
	public void addEmployee(EmployeeVO employeeVo);
	public List<DepartmentVO> getDepartments();
}
