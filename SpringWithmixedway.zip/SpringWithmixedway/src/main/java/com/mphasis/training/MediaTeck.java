package com.mphasis.training;

import org.springframework.stereotype.Component;

@Component
public class MediaTeck implements Processor {

	public MediaTeck() {
		System.out.println("Media Teck Processor");
	}
	
	public void process() {
		System.out.println("mediateck called");
	}

}
