package com.mphasis.training;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class I5Processor implements Processor {

	public I5Processor() {
		System.out.println("I5processor");
	}
	
	public void process() {
		// TODO Auto-generated method stub
System.out.println("i5 processor called");
	}

}
