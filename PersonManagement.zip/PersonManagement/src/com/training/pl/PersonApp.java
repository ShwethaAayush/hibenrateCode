package com.training.pl;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Writer;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.Scanner;

import javax.sql.rowset.serial.SerialBlob;

import com.training.daos.PersonDao;
import com.training.daos.PersonDaoImpl;
import com.training.pojo.Person;
import com.training.util.DbUtil;

public class PersonApp {

	public static void main(String[] args) throws SQLException, IOException {
		Scanner sc=new Scanner(System.in);
		PersonDao personDao=new PersonDaoImpl();
		do {
			System.out.println("1. Insert Person \n 2.Retrive Person By AdarNumber\n 3.AdarNum");
			int choice=sc.nextInt();
			if(choice==1) {
				System.out.println("Enter Person Details");
				Person p=new Person();
				System.out.println("enter adarNum");
				p.setAdarNum(sc.nextLong());
				System.out.println("Enter name");
				p.setPname(sc.next());
				System.out.println("Enter PhNUm");
				p.setPh_num(sc.nextLong());
				System.out.println("enter Photo location");
				//FileInputStream fis=new FileInputStream(sc.next());
//				Clob myClob = DbUtil.openConnection().createClob();
//		        Writer clobWriter = myClob.setCharacterStream(1);
//		        String str = clobWriter.readFile(sc.next(), clobWriter);
				//ObjectInputStream oos=new ObjectInputStream(fis);
			//	p.setPhoto();
				System.out.println("enter resume");
			//	FileReader fr=new FileReader(sc.next());
				//Clob clob=DbUtil.openConnection().createClob();
				//p.setResume((Clob) fr);
				//p.setResume();
				int i=personDao.insertPerson(p);
				if(i>0) {
					System.out.println("Added");
				}
				
				
			}else if(choice ==2) {
				
			}else if(choice ==3) {
				System.out.println("thank you");
				System.exit(0);
			}else {
				System.out.println("invalid");
			}
		}while(true);
	}

}
