package com.training.pojo;

import java.sql.Blob;
import java.sql.Clob;


public class Person {
	
	private long adarNum;
	private String pname;
	private long ph_num;
	private Blob photo;
	private Clob resume;
	
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public long getPh_num() {
		return ph_num;
	}
	public void setPh_num(long ph_num) {
		this.ph_num = ph_num;
	}
	public Blob getPhoto() {
		return photo;
	}
	public void setPhoto(Blob photo) {
		this.photo = photo;
	}
	public Clob getResume() {
		return resume;
	}
	public void setResume(Clob resume) {
		this.resume = resume;
	}
	public long getAdarNum() {
		return adarNum;
	}
	public void setAdarNum(long adarNum) {
		this.adarNum = adarNum;
	}
	
	
	
	

}
