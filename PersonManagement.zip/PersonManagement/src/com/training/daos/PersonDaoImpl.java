package com.training.daos;

import java.io.InputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.training.pojo.Person;
import com.training.util.DbUtil;

public class PersonDaoImpl  implements PersonDao {

	Connection con;
	 public PersonDaoImpl() {
		// TODO Auto-generated constructor stub
		con=DbUtil.openConnection();
	}
	
	@Override
	public int insertPerson(Person p) {
		int i=0;
		try {
			String sql="insert into person values(?,?,?,?,?)";
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setLong(1, p.getAdarNum());
		pst.setString(2, p.getPname());
		pst.setLong(3, p.getPh_num());
		//pst.setBytes(4, p.getPhoto());
		//pst.setNCharacterStream(5, p.getResume());
		pst.setBlob(4, p.getPhoto());
		pst.setClob(5, p.getResume());
		i=pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public Person retirvePersonByAdarNum(long adarNum) {
		Person p=new Person();
		try {
			String sql="select * from person where adarNum=?";
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setLong(1, p.getAdarNum());
		ResultSet rs=pst.executeQuery();
		if(rs.next()) {
			p.setAdarNum(adarNum);
			p.setPname(rs.getString(2));
			p.setPh_num(rs.getLong(3));
			p.setPhoto(rs.getBlob(4));
			p.setResume(rs.getClob(5));
		}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return p;
	}

}
