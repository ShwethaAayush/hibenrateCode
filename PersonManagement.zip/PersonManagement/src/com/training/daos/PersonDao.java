package com.training.daos;

import com.training.pojo.Person;

public interface PersonDao {

	public int insertPerson(Person p);
	public Person retirvePersonByAdarNum(long adarNum);
}
