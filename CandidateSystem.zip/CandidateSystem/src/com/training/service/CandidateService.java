package com.training.service;

import java.util.List;
import java.util.Optional;

import com.training.pojos.Candidate;

public interface CandidateService {	
	public List<Candidate> getCandidates();
	public void addCandidate(Candidate candidate);
	public Optional<Candidate> getCandidate(int id);
}
